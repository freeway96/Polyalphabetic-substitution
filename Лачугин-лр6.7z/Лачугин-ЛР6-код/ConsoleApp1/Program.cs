﻿using System;
using System.Numerics;

class RSA
{
    private BigInteger p, q, n, m, e, d;

    public RSA(BigInteger p, BigInteger q)
    {
        this.p = p;
        this.q = q;
        n = p * q;
        m = (p - 1) * (q - 1);
        d = CalculateD(m);
        e = CalculateE(d, m);
    }

    private BigInteger CalculateD(BigInteger m)
    {
        BigInteger d = 2;
        while (d < m)
        {
            if (BigInteger.GreatestCommonDivisor(d, m) == 1)
                return d;
            d++;
        }
        return d;
    }

    private BigInteger CalculateE(BigInteger d, BigInteger m)
    {
        BigInteger e = 1;
        while (true)
        {
            if ((e * d) % m == 1)
                return e;
            e++;
        }
    }

    public BigInteger Encrypt(BigInteger message)
    {
        return BigInteger.ModPow(message, e, n);
    }

    public BigInteger Decrypt(BigInteger cipher)
    {
        return BigInteger.ModPow(cipher, d, n);
    }
}

class ElGamal
{
    private BigInteger p, a, x, y;

    public ElGamal(BigInteger p, BigInteger a, BigInteger x)
    {
        this.p = p;
        this.a = a;
        this.x = x;
        y = BigInteger.ModPow(a, x, p);
    }

    public (BigInteger, BigInteger) Encrypt(BigInteger message, BigInteger k)
    {
        BigInteger r = BigInteger.ModPow(a, k, p);
        BigInteger e = (message * BigInteger.ModPow(y, k, p)) % p;
        return (r, e);
    }

    public BigInteger Decrypt((BigInteger, BigInteger) cipher)
    {
        BigInteger r = cipher.Item1;
        BigInteger e = cipher.Item2;
        BigInteger rInverse = BigInteger.ModPow(r, p - 1 - x, p);
        return (e * rInverse) % p;
    }
}

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Алгоритм RSA:");
        RSA rsa = new RSA(5, 11);

        string message = "ЛИД";
        Console.WriteLine("Исходный текст: " + message);

        string encryptedMessage = "";
        foreach (char c in message)
        {
            BigInteger encryptedChar = rsa.Encrypt(c - 'А' + 1);
            encryptedMessage += encryptedChar.ToString() + " ";
        }
        Console.WriteLine("Зашифрованный текст: " + encryptedMessage.Trim());

        string decryptedMessage = "";
        foreach (string part in encryptedMessage.Trim().Split(' '))
        {
            BigInteger decryptedChar = rsa.Decrypt(BigInteger.Parse(part));
            decryptedMessage += (char)(decryptedChar + 'А' - 1);
        }
        Console.WriteLine("Расшифрованный текст: " + decryptedMessage);



        Console.WriteLine("\nАлгоритм Эль-Гамаль:");
        ElGamal elGamal = new ElGamal(17, 3, 7);

        message = "ЛИД";
        Console.WriteLine("Исходный текст: " + message);

        BigInteger k = 11;
        foreach (char c in message)
        {
            BigInteger numericMessage = c - 'А' + 1;
            var encryptedMessageElGamal = elGamal.Encrypt(numericMessage, k);
            Console.WriteLine("Зашифрованный текст: (" + encryptedMessageElGamal.Item1 + ", " + encryptedMessageElGamal.Item2 + ")");

            BigInteger decryptedMessageElGamal = elGamal.Decrypt(encryptedMessageElGamal);
            Console.WriteLine("Расшифрованный текст: " + (char)(decryptedMessageElGamal + 'А' - 1));
        }
    }
}